Usage:

Requirements:
1) The shell has to be compiled with --enable-gctimer

2) The JS_WANT_GC_SUITE_PRINT flag has to be set to true in jsgc.cpp

Tested with python2.6
