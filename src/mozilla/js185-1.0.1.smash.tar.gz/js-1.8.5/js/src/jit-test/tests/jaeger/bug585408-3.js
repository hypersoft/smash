(function() {
  function a() {}
  a > a--
})()

/* Don't assert. */

