for (a = 0; a < HOTLOOP + 5; a++) {
    (function n() { {
            function s() {}
        }
        yield[];
    }());
}

/* Don't assert. */

