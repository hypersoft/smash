// |jit-test| error: TypeError;
var bts = true.toString;
bts();
