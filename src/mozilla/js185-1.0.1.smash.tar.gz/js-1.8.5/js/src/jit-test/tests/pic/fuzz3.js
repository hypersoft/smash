for each(let w in [[], 0, [], 0]) {
  w.unwatch()
}
