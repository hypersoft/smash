assertEq(Infinity >= Infinity ? true : false, true);
