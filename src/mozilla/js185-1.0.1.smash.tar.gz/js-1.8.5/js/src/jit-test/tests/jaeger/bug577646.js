try {
  []();
} catch(e) {}

/* Don't crash. */
