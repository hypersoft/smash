function testHOTLOOPSize() {
    return HOTLOOP > 1;
}
assertEq(testHOTLOOPSize(), true);
