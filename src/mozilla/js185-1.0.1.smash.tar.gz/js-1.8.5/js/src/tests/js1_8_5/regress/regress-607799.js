reportCompare(typeof(evalcx("/x/")), "object")
